<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beli</title>
    <style>
      .container form button{
    width: 20%;
    height: 40px;
    padding: 5px 0;
    border: none;
    background-color:#752BEA;
    font-size: 18px;
    color: #fafafa;
    border-radius: 20px;
}
    </style>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">
    <div class="Zalora" id="Zalora">
        <div class="container text-center">
            <div class="row">
                <center><h1>Gramedia</h1>
		  <p>Projeck Penjualan Buku By | Ripa Noval Kh | XII RPL 2 😁</p></center  
                </div>
            </div>
            <div class="nav">
            <ul class="nav nav-tabs">
                <li ><a href="beranda.php">Beranda</a></li>
                <li ><a href="about.html">About</a></li>
                <li ><a href="Login.php">Log out</a></li>
                <div class="col-sm-5 col-sm-offset-8">
                    <form class="form-inline md-form mr-auto mb-4">
                      <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
                      <button class="btn aqua-gradient btn-rounded btn-sm my-0" type="submit">Search</button>
                    </form>
                  </div>
                  </ul>
  </head>
  <body>
    
    <section class="new product" id="new product">
            <section class="container">
                <div class="row"> 
                   <hr>    
                    <div class="col-sm-4">
                        <a class="thumbnail">
                        <img src="img/download.jfif">
                        </a>
                        </div> 
                        <p align="left"> BUKU CATATAN / NOTE BOOK / NOTE BOOK SIMPLE </p>
                        <p align="left">5.0 ⭐⭐⭐⭐⭐ | 173 Penilaian | 412 Terjual</p> 
                        <p align="left">Rp 249.000</p>
                        <br><br>
                        <p  align="justify" >Simpel dan elegan ,buku catatan
                             limited edition -bahan isi dari kertas Brown craft 90 gsm cetak
                            2 sisi 50 lembar (100 halaman) -bahan isi concorde 90 gsm cetak 2 sis
                            i 40 lembar ( 80 halaman ) Ada 2 pilihan cover -Craft paper 350 gsm -
                            Jasmine paper 310 gsm Dengan finishing spiral membuat buku ini semakin
                            menawan. <a href=""> #bukucatatan#notebook#buku#notebook</a></p>
                        </div>
                        </section>
                        <hr>
                        <tr>
                          <td>
                            <p align="left">Stok hampir habis Tersisa <5 </p>
                            <p align="left">Harga Barang    Rp 249.000</p>
                            <td>Nama : </td>
                            <input type="alamat">
                            <br><br>
                            <td></td>
                            <td>Alamat : </td>
                            <td><textarea name="alamat" id="" cols="30" rows="1"></textarea></td>
                          </td>
                        </tr>
                    </div>

                        <br>
                        <tr>
                          <b><P>Catatana untuk penjula : <P></b>
                          <td><textarea name="alamat" id="" cols="30" rows="1" placeholder="" required></textarea></td>
                        </tr>
                        <br>
                        <select><option name="alamat" value="0">Metode Pembayaran</option>
                        <option value="1">Cuman Cod</option>
                      </select>
                        <div class="c">
                          <form>
                            <button clas=""><a href="konfirmasi.php" style="color:white">Komfirmasi</a></button>
                          </form>
                        </div>
                        
    <footer>
        <hr>  
        <div class="container text-center">
          <div class="row">
            <p> &copy; Copyright 2020 | 2020 created by Ripa Noval Kh <i class="glyphicon glyphicon-user"></i>
              <a href="https://www.instagram.com/ripanaupal/">Ripa Noval Kh</a>
            </p>
          </div>
        </div>
        <hr>
      </footer>
  </body >
</html>